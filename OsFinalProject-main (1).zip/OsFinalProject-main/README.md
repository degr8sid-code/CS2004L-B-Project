# Team J
**_Group Members are_**
## Rohin
## Saad Ali
## Muhammad Raza

### 1. dig command

![dig](https://user-images.githubusercontent.com/99000179/154740351-c9850392-4a88-46d0-bd38-b247ecd3ec93.jpg)

![dig2](https://user-images.githubusercontent.com/99000179/154740405-c8423907-5073-4961-abaa-98257105a702.jpg)

### 2. iptables command

![iptables](https://user-images.githubusercontent.com/99000179/154740867-531cf470-95c0-4100-b261-356cedd8e562.jpg)

### 3. mtr command
![mtr](https://user-images.githubusercontent.com/99000179/154740993-7b814e7d-17db-4446-892b-2fb6c1ccc5ea.jpg)

### 4. netstate command
![netstate](https://user-images.githubusercontent.com/99000179/154741075-b41269b2-d116-45f9-818c-5eb1e2853f19.jpg)

![netstate2](https://user-images.githubusercontent.com/99000179/154741082-4162584a-d982-463b-b40f-489cb021a1bd.jpg)

![netstate3](https://user-images.githubusercontent.com/99000179/154741084-119db0fa-2de8-47f2-ae51-c0a71e926853.jpg)

![netstate4](https://user-images.githubusercontent.com/99000179/154741087-6a2e1b52-6a94-4019-bed4-c15dee0e91bb.jpg)

### 5. nmap command
![nmap](https://user-images.githubusercontent.com/99000179/154741161-7ea39932-0cee-4064-82f2-f49e29af775f.jpg)

![nmap2](https://user-images.githubusercontent.com/99000179/154741154-402bf654-407f-4228-a7f8-3c3ff920a03c.jpg)

### 6. ping command
![ping](https://user-images.githubusercontent.com/99000179/154741254-6e867776-a047-45a6-a4dd-649dbddd4e6a.jpg)

![ping2](https://user-images.githubusercontent.com/99000179/154741258-4e777ed2-14f7-4823-8c14-05e514981946.jpg)

### 7. tcpdump command
![tcpdump](https://user-images.githubusercontent.com/99000179/154741262-2b26668e-fec0-4458-acaa-017f9e88bda9.jpg)

### 8. traceroute command
![traceroute](https://user-images.githubusercontent.com/99000179/154741265-95b923e7-217a-4c38-a323-9f6e001b7d33.jpg)


# **USE KUBERNETES ON LOCALHOST** 
**First Step**: OPEN POWERSHELL (RUN AS ADMINISTRATOR)
```sh
OPEN WINDOWS POWERSHELL (THROUGH START MENU)
```
<img src="D:\DSU\OS Lab\Project\1.png" align="center" style="height: 100px width: 100px"/>

**Second Step**: _DOWNLOAD CHOCOLATEY_
```sh
"Set-ExecutionPolicy Bypass -Scope Process -Force; [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))"
```
<img src="D:\DSU\OS Lab\Project\2.png" align="center" style="height: 100px width: 100px"/>

**Third Step**: _CHECK CHOCOLATEY_
```sh
"choco"
```
<img src="D:\DSU\OS Lab\Project\3.png" align="center" style="height: 100px width: 100px"/>

**Fourth Step**: _INSTALL KUBERNETES CLI_
```sh
"choco install kubernetes-cli"
```
<img src="D:\DSU\OS Lab\Project\4.png" align="center" style="height: 100px width: 100px"/>

**Fifth Step**: _INSTALL MINIKUBE_
```sh
Pressing "choco install minikube"
```
<img src="D:\DSU\OS Lab\Project\5.png" align="center" style="height: 100px width: 100px"/>

**Sixth Step**: _ENABLE HYPER V_
```sh
"THROUGH PROGRAM & FEATURES"
```
<img src="D:\DSU\OS Lab\Project\6.png" align="center" style="height: 100px width: 100px"/>

**Seventh Step**: _START MINIKUBE_
```sh
"minikube start"
```
<img src="D:\DSU\OS Lab\Project\7.png" align="center" style="height: 100px width: 100px"/>

**Eight Step**: _CHECK MINIKUBE STATUS_
```sh
"minikube status"
```
<img src="D:\DSU\OS Lab\Project\8.png" align="center" style="height: 100px width: 100px"/>

**Ninth Step**: _OPEN KUBERNETES DASHBOARD_
```sh
"minikube dashboard"
```
<img src="D:\DSU\OS Lab\Project\9.png" align="center" style="height: 100px width: 100px"/>

**Tenth Step**: _KUBERNETES DASHBOARD_
```sh
Using Kubernetes on localhost
```
<img src="D:\DSU\OS Lab\Project\10.png" align="center" style="height: 100px width: 100px"/>

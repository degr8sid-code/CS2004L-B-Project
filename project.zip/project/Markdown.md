# OS Lab Project 

**Shaheer Zia   CS192017**

**Saad bin Wasi CS192016**

## How to Set up Apache Tomchat on Linux

1:Make a directory for apache tomcat

2: Use wget command to download tar file using the link obtained from the apache tomcat project site.

3: Decompress file in tomcat folder

4: Install Java
 
 <img src="D:\DSU\OS Lab\Project\Project\1.jpeg" align="center" style="height: 100px width: 100px"/>

<img src="D:\DSU\OS Lab\Project\Project\2.jpeg" align="center" style="height: 100px width: 100px"/>

6: Configure .bashrc file
 <img src="D:\DSU\OS Lab\Project\Project\3.png" align="center" style="height: 100px width: 100px"/>

7: Add the following lines at the end of the fill


<img src="D:\DSU\OS Lab\Project\Project\4.jpeg" align="center" style="height: 100px width: 100px"/>

8: Run the following command to make the changes take effect
 
 <img src="D:\DSU\OS Lab\Project\Project\5.png" align="center" style="height: 100px width: 100px"/>

9: Tomcat and java are now installed and configured, run the following script to run tomcat

<img src="D:\DSU\OS Lab\Project\Project\6.png" align="center" style="height: 100px width: 100px"/>

<img src="D:\DSU\OS Lab\Project\Project\7.jpeg" align="center" style="height: 100px width: 100px"/>


# Maaz Tariq     CS191063
# Anas Siddiqui     CS211251

### Creating Repository  

<! https://github.com/maaztariq123/Kulfi/blob/main/Images/1.jpeg  
<! https://github.com/maaztariq123/Kulfi/blob/main/Images/2.jpeg  
<! https://github.com/maaztariq123/Kulfi/blob/main/Images/3.jpeg  

### Using Github Actions    

<! https://github.com/maaztariq123/Kulfi/blob/main/Images/4.jpeg  

### Creating Work Flow  

<! https://github.com/maaztariq123/Kulfi/blob/main/Images/5.jpeg  

### Successfully Run Workflow  

<! https://github.com/maaztariq123/Kulfi/blob/main/Images/6.jpeg  

### Adding .net File  

<! https://github.com/maaztariq123/Kulfi/blob/main/Images/7.jpeg  

### Successfully .net File On a Work Flow

<! https://github.com/maaztariq123/Kulfi/blob/main/Images/8.jpeg  
<! https://github.com/maaztariq123/Kulfi/blob/main/Images/9.jpeg  

### C# Code

<! https://github.com/maaztariq123/Kulfi/blob/main/Images/c%20%23%20Project%20CODE.PNG

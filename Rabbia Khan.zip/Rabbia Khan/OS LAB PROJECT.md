# **OS LAB PROJECT**
## Project Documentation
---
Project Name: Github Actions  (building and testing java with gradle)

Team C

---
## Table of Contents
* GitHub Actions.
* Java Code File.
* Files and it's usage followed by screenshots
* Languages Used
* IDE Compatibility


---
## 1. GitHub Actions
Project essential functionality is on GitHub Actions:

>Automate, customize, and execute your software development workflows right in your repository with GitHub Actions. You can discover, create, and share actions to perform any job you'd like, including CI/CD, and combine actions in a completely customized workflow.
[See more on Github Actions](https://docs.github.com/en/actions)

Github Actions that has been covered in this project are as follows:
1. Building Java with Gradle
2. Testing Java with Gradle

---
## 2. JAVA Code File:
> The main purpose of this file is to demonstrate the GitHub Actions of building and testing Java using Gradle. The popular line "Hello World" is output by the code. The task of building and testing Java with Gradle is completed on execution.

##### `Sample Code Screenshot:`
<img src="C:\Users\asd\Downloads\OS_project-master\ss2.jpg" align="center" style="height: 100px width: 100px"/>
<img src="C:\Users\asd\Downloads\OS_project-master\ss3.jpg" align="center" style="height: 100px width: 100px"/>


---

## 3. Files and it's usage followed by screenshots:
Project workflow explains basic workflow in more detail to help you get started with GitHub Actions.
It contain the following important concepts:
1. Controls
2. Jobs
3. Build
4. Steps


##### `Sample ScreenShot:`

<img src="C:\Users\asd\Downloads\OS_project-master\ss4.jpg" align="center" style="height: 100px width: 100px"/>
<img src="C:\Users\asd\Downloads\OS_project-master\ss5.jpg" align="center" style="height: 100px width: 100px"/>
<img src="C:\Users\asd\Downloads\OS_project-master\ss6.jpg" align="center" style="height: 100px width: 100px"/>
<img src="C:\Users\asd\Downloads\OS_project-master\ss7.jpg" align="center" style="height: 100px width: 100px"/>

---
## 4.  Languages Used
- JAVA

---
## 5. IDE Compatibility
- All Java IDE and Gradle